<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Online Exam System</title>

    <link rel="stylesheet" href="css/test.css">
  </head>
  <body>
    <div class="main">
        <div class="header">
          <img src="img/mainheader.jpg" alt="" >
        </div>
        <div class="mainmenue">
          <a class="active" href="#">Home</a>
          <a href="#">Test</a>
          <a href="#">Notice</a>
          <a href="#">Profile</a>
          <a href="#">Ranking</a>
          <a href="#" style="border:none;">Contact Us</a>
        </div>
        <div class="mainbody">
          <h3>Manage Your Profile</h3>
          <div class="content">
            <a href="#"> View Profile</a><br><br>
            <a href="#"> Change Password</a><br><br>
            <a href="#"> Logout</a>

          </div>

    </div>
    <div class="footer">
      <p>Copright &copy; 2018 Md. Osman Gani,  &nbsp;&nbsp;&nbsp; <a href="">LICT TUP-UP-BDJ-22, Dinajpur.</a></p>
    </div>

  </body>
</html>

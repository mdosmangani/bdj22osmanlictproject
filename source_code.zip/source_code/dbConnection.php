<?php


// ******All the variables defined here are accessible in all the files that include this one******

$con= new mysqli('localhost','bdj22osmanlictpr','a)da.S]Y$&hq','bdj22osm_osmanoes')or die("Could not connect to mysql".mysqli_error($con));

?>
